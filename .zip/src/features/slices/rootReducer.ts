// rootReducer.js
// import { combineReducers } from 'redux';
// // import authReducer from './authReducer'; // Your authentication reducer
// // import {authReucers} from "../slices/authReducer"
// import authSlice from './authSlice';


// const rootReducer = combineReducers({
//   auth: authSlice,

// });

// export default rootReducer;
