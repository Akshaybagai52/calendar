"use client"
import Footer from "@/components/homeSections/footer"
import BlogSection from "../../components/blogSections/blogSection"
export default function Blogs() {
  return (
    <div>
      <BlogSection />
      <Footer/>
    </div>
  )
}
