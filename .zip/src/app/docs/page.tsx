export default function Docs() {
  return (
    <div>
      <main className="flex min-h-screen flex-col items-center justify-between p-24">
        <h1>Docs Page</h1>
      </main>
    </div>
  )
}
