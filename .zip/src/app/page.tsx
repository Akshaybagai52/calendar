import HomePage from "@/components/homePage"

export default function Home() {
 
  return (
   <>
   <HomePage />
   </>

  )
}
