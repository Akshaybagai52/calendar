

import Reminders  from '@/components/bookingSchedule/reminders ';
import React from 'react'
 const BookingToday =()=>{
    return(
        <div className='mt-[78px] pt-5'>
        <Reminders/>
        </div>
    )
}
export default BookingToday;