"use client"
import React from 'react'
const TokenZen=()=>{
    
//  const genrateToken=(setTokenGen: (token: string) => void) =>{
  
//   const { data:tokenData, error:errorToken } = useSWR(
//     "https://www.universal-tutorial.com/api/getaccesstoken",
//     (url) =>
//     fetch(url, {
//       method: "GET",
//       headers: {
//         "Accept": "application/json",
//         "api-token":"k930IlEKrjOFxEzaqgR9BMTXMBVRZwd0BcdAeAQNXWnSwpQvsFks50dt_FCtlo9og0Q",
//         "user-email":"satnamsingh85611@gmail.com"
//       },
//     })
//   );

// };

//  }
}