import './corss.css'
export const CorssSvg = () => {
  return (
    <div className="corss_main">
        <div className='close-container'>
        <div className="leftright"></div>
        <div className="rightleft"></div>
        <label className="close">close</label>
      </div>
    </div>
  );
};
