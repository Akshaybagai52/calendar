export const FeedbackData =[
    {
        name:'user_name',
        label:'Name',
        type:'text'
    },
    {
        name:'user_email',
        label:'Email',
        type:'email'
    },

]
export const FeedbackDataMessage=[
    {
        label:'Message',
        name:'feedback',
        type:'text'
    }
]